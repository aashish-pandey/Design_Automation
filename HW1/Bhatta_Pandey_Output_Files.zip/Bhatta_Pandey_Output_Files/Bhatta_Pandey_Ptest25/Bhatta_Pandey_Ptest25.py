# Auto - generated optimized placement
data = {
    'cells': {
        'CELL_0': {
            'fixed': False,
            'position': (6, 2),
            'type': 'MOVABLE'
        },
        'CELL_1': {
            'fixed': False,
            'position': (5, 2),
            'type': 'MOVABLE'
        },
        'CELL_10': {
            'fixed': False,
            'position': (5, 0),
            'type': 'MOVABLE'
        },
        'CELL_11': {
            'fixed': False,
            'position': (6, 0),
            'type': 'MOVABLE'
        },
        'CELL_12': {
            'fixed': False,
            'position': (6, 1),
            'type': 'MOVABLE'
        },
        'CELL_13': {
            'fixed': False,
            'position': (6, 5),
            'type': 'MOVABLE'
        },
        'CELL_14': {
            'fixed': False,
            'position': (6, 6),
            'type': 'MOVABLE'
        },
        'CELL_15': {
            'fixed': False,
            'position': (4, 6),
            'type': 'MOVABLE'
        },
        'CELL_16': {
            'fixed': False,
            'position': (4, 5),
            'type': 'MOVABLE'
        },
        'CELL_17': {
            'fixed': False,
            'position': (1, 5),
            'type': 'MOVABLE'
        },
        'CELL_18': {
            'fixed': False,
            'position': (0, 6),
            'type': 'MOVABLE'
        },
        'CELL_19': {
            'fixed': False,
            'position': (0, 5),
            'type': 'MOVABLE'
        },
        'CELL_2': {
            'fixed': False,
            'position': (5, 3),
            'type': 'MOVABLE'
        },
        'CELL_20': {
            'fixed': False,
            'position': (0, 4),
            'type': 'MOVABLE'
        },
        'CELL_21': {
            'fixed': False,
            'position': (0, 2),
            'type': 'MOVABLE'
        },
        'CELL_22': {
            'fixed': False,
            'position': (0, 1),
            'type': 'MOVABLE'
        },
        'CELL_3': {
            'fixed': False,
            'position': (4, 3),
            'type': 'MOVABLE'
        },
        'CELL_4': {
            'fixed': False,
            'position': (3, 3),
            'type': 'MOVABLE'
        },
        'CELL_5': {
            'fixed': False,
            'position': (2, 3),
            'type': 'MOVABLE'
        },
        'CELL_6': {
            'fixed': False,
            'position': (2, 2),
            'type': 'MOVABLE'
        },
        'CELL_7': {
            'fixed': False,
            'position': (2, 1),
            'type': 'MOVABLE'
        },
        'CELL_8': {
            'fixed': False,
            'position': (1, 0),
            'type': 'MOVABLE'
        },
        'CELL_9': {
            'fixed': False,
            'position': (4, 0),
            'type': 'MOVABLE'
        },
        'IO_0': {
            'fixed': True,
            'position': (1, 6),
            'type': 'IO'
        },
        'IO_1': {
            'fixed': True,
            'position': (0, 0),
            'type': 'IO'
        }
    },
    'grid_size': 7,
    'nets': [{
        'cells': ('CELL_0', 'CELL_1'),
        'name': 'NET_0'
    }, {
        'cells': ('CELL_1', 'CELL_2'),
        'name': 'NET_1'
    }, {
        'cells': ('CELL_2', 'CELL_3'),
        'name': 'NET_2'
    }, {
        'cells': ('CELL_3', 'CELL_4'),
        'name': 'NET_3'
    }, {
        'cells': ('CELL_4', 'CELL_5'),
        'name': 'NET_4'
    }, {
        'cells': ('CELL_5', 'CELL_6'),
        'name': 'NET_5'
    }, {
        'cells': ('CELL_6', 'CELL_7'),
        'name': 'NET_6'
    }, {
        'cells': ('CELL_7', 'CELL_8'),
        'name': 'NET_7'
    }, {
        'cells': ('CELL_8', 'CELL_9'),
        'name': 'NET_8'
    }, {
        'cells': ('CELL_9', 'CELL_10'),
        'name': 'NET_9'
    }, {
        'cells': ('CELL_10', 'CELL_11'),
        'name': 'NET_10'
    }, {
        'cells': ('CELL_11', 'CELL_12'),
        'name': 'NET_11'
    }, {
        'cells': ('CELL_12', 'CELL_13'),
        'name': 'NET_12'
    }, {
        'cells': ('CELL_13', 'CELL_14'),
        'name': 'NET_13'
    }, {
        'cells': ('CELL_14', 'CELL_15'),
        'name': 'NET_14'
    }, {
        'cells': ('CELL_15', 'CELL_16'),
        'name': 'NET_15'
    }, {
        'cells': ('CELL_16', 'CELL_17'),
        'name': 'NET_16'
    }, {
        'cells': ('CELL_17', 'CELL_18'),
        'name': 'NET_17'
    }, {
        'cells': ('CELL_18', 'CELL_19'),
        'name': 'NET_18'
    }, {
        'cells': ('CELL_19', 'CELL_20'),
        'name': 'NET_19'
    }, {
        'cells': ('CELL_20', 'CELL_21'),
        'name': 'NET_20'
    }, {
        'cells': ('CELL_21', 'CELL_22'),
        'name': 'NET_21'
    }, {
        'cells': ('IO_0', 'CELL_18'),
        'name': 'NET_22'
    }, {
        'cells': ('IO_1', 'CELL_8'),
        'name': 'NET_23'
    }]
}