# Auto - generated optimized placement
data = {
    'cells': {
        'CELL_0': {
            'fixed': False,
            'position': (0, 8),
            'type': 'MOVABLE'
        },
        'CELL_1': {
            'fixed': False,
            'position': (1, 8),
            'type': 'MOVABLE'
        },
        'CELL_10': {
            'fixed': False,
            'position': (6, 8),
            'type': 'MOVABLE'
        },
        'CELL_11': {
            'fixed': False,
            'position': (7, 8),
            'type': 'MOVABLE'
        },
        'CELL_12': {
            'fixed': False,
            'position': (8, 8),
            'type': 'MOVABLE'
        },
        'CELL_13': {
            'fixed': False,
            'position': (8, 6),
            'type': 'MOVABLE'
        },
        'CELL_14': {
            'fixed': False,
            'position': (8, 5),
            'type': 'MOVABLE'
        },
        'CELL_15': {
            'fixed': False,
            'position': (6, 2),
            'type': 'MOVABLE'
        },
        'CELL_16': {
            'fixed': False,
            'position': (6, 0),
            'type': 'MOVABLE'
        },
        'CELL_17': {
            'fixed': False,
            'position': (5, 0),
            'type': 'MOVABLE'
        },
        'CELL_18': {
            'fixed': False,
            'position': (7, 0),
            'type': 'MOVABLE'
        },
        'CELL_19': {
            'fixed': False,
            'position': (8, 0),
            'type': 'MOVABLE'
        },
        'CELL_2': {
            'fixed': False,
            'position': (4, 8),
            'type': 'MOVABLE'
        },
        'CELL_20': {
            'fixed': False,
            'position': (8, 1),
            'type': 'MOVABLE'
        },
        'CELL_21': {
            'fixed': False,
            'position': (8, 2),
            'type': 'MOVABLE'
        },
        'CELL_22': {
            'fixed': False,
            'position': (7, 2),
            'type': 'MOVABLE'
        },
        'CELL_23': {
            'fixed': False,
            'position': (3, 2),
            'type': 'MOVABLE'
        },
        'CELL_24': {
            'fixed': False,
            'position': (3, 3),
            'type': 'MOVABLE'
        },
        'CELL_25': {
            'fixed': False,
            'position': (3, 1),
            'type': 'MOVABLE'
        },
        'CELL_26': {
            'fixed': False,
            'position': (3, 0),
            'type': 'MOVABLE'
        },
        'CELL_27': {
            'fixed': False,
            'position': (1, 0),
            'type': 'MOVABLE'
        },
        'CELL_28': {
            'fixed': False,
            'position': (2, 0),
            'type': 'MOVABLE'
        },
        'CELL_29': {
            'fixed': False,
            'position': (2, 1),
            'type': 'MOVABLE'
        },
        'CELL_3': {
            'fixed': False,
            'position': (5, 8),
            'type': 'MOVABLE'
        },
        'CELL_30': {
            'fixed': False,
            'position': (2, 2),
            'type': 'MOVABLE'
        },
        'CELL_31': {
            'fixed': False,
            'position': (1, 2),
            'type': 'MOVABLE'
        },
        'CELL_32': {
            'fixed': False,
            'position': (1, 1),
            'type': 'MOVABLE'
        },
        'CELL_33': {
            'fixed': False,
            'position': (0, 1),
            'type': 'MOVABLE'
        },
        'CELL_34': {
            'fixed': False,
            'position': (0, 2),
            'type': 'MOVABLE'
        },
        'CELL_35': {
            'fixed': False,
            'position': (0, 3),
            'type': 'MOVABLE'
        },
        'CELL_36': {
            'fixed': False,
            'position': (0, 4),
            'type': 'MOVABLE'
        },
        'CELL_37': {
            'fixed': False,
            'position': (0, 5),
            'type': 'MOVABLE'
        },
        'CELL_38': {
            'fixed': False,
            'position': (0, 7),
            'type': 'MOVABLE'
        },
        'CELL_39': {
            'fixed': False,
            'position': (1, 7),
            'type': 'MOVABLE'
        },
        'CELL_4': {
            'fixed': False,
            'position': (5, 6),
            'type': 'MOVABLE'
        },
        'CELL_40': {
            'fixed': False,
            'position': (1, 6),
            'type': 'MOVABLE'
        },
        'CELL_41': {
            'fixed': False,
            'position': (2, 5),
            'type': 'MOVABLE'
        },
        'CELL_42': {
            'fixed': False,
            'position': (2, 6),
            'type': 'MOVABLE'
        },
        'CELL_43': {
            'fixed': False,
            'position': (2, 7),
            'type': 'MOVABLE'
        },
        'CELL_44': {
            'fixed': False,
            'position': (2, 8),
            'type': 'MOVABLE'
        },
        'CELL_5': {
            'fixed': False,
            'position': (4, 5),
            'type': 'MOVABLE'
        },
        'CELL_6': {
            'fixed': False,
            'position': (4, 4),
            'type': 'MOVABLE'
        },
        'CELL_7': {
            'fixed': False,
            'position': (5, 4),
            'type': 'MOVABLE'
        },
        'CELL_8': {
            'fixed': False,
            'position': (6, 4),
            'type': 'MOVABLE'
        },
        'CELL_9': {
            'fixed': False,
            'position': (7, 7),
            'type': 'MOVABLE'
        },
        'IO_0': {
            'fixed': True,
            'position': (3, 8),
            'type': 'IO'
        },
        'IO_1': {
            'fixed': True,
            'position': (0, 0),
            'type': 'IO'
        },
        'IO_2': {
            'fixed': True,
            'position': (8, 3),
            'type': 'IO'
        },
        'IO_3': {
            'fixed': True,
            'position': (4, 0),
            'type': 'IO'
        },
        'IO_4': {
            'fixed': True,
            'position': (8, 7),
            'type': 'IO'
        }
    },
    'grid_size': 9,
    'nets': [{
        'cells': ('CELL_0', 'CELL_1'),
        'name': 'NET_0'
    }, {
        'cells': ('CELL_1', 'CELL_2'),
        'name': 'NET_1'
    }, {
        'cells': ('CELL_2', 'CELL_3'),
        'name': 'NET_2'
    }, {
        'cells': ('CELL_3', 'CELL_4'),
        'name': 'NET_3'
    }, {
        'cells': ('CELL_4', 'CELL_5'),
        'name': 'NET_4'
    }, {
        'cells': ('CELL_5', 'CELL_6'),
        'name': 'NET_5'
    }, {
        'cells': ('CELL_6', 'CELL_7'),
        'name': 'NET_6'
    }, {
        'cells': ('CELL_7', 'CELL_8'),
        'name': 'NET_7'
    }, {
        'cells': ('CELL_8', 'CELL_9'),
        'name': 'NET_8'
    }, {
        'cells': ('CELL_9', 'CELL_10'),
        'name': 'NET_9'
    }, {
        'cells': ('CELL_10', 'CELL_11'),
        'name': 'NET_10'
    }, {
        'cells': ('CELL_11', 'CELL_12'),
        'name': 'NET_11'
    }, {
        'cells': ('CELL_12', 'CELL_13'),
        'name': 'NET_12'
    }, {
        'cells': ('CELL_13', 'CELL_14'),
        'name': 'NET_13'
    }, {
        'cells': ('CELL_14', 'CELL_15'),
        'name': 'NET_14'
    }, {
        'cells': ('CELL_15', 'CELL_16'),
        'name': 'NET_15'
    }, {
        'cells': ('CELL_16', 'CELL_17'),
        'name': 'NET_16'
    }, {
        'cells': ('CELL_17', 'CELL_18'),
        'name': 'NET_17'
    }, {
        'cells': ('CELL_18', 'CELL_19'),
        'name': 'NET_18'
    }, {
        'cells': ('CELL_19', 'CELL_20'),
        'name': 'NET_19'
    }, {
        'cells': ('CELL_20', 'CELL_21'),
        'name': 'NET_20'
    }, {
        'cells': ('CELL_21', 'CELL_22'),
        'name': 'NET_21'
    }, {
        'cells': ('CELL_22', 'CELL_23'),
        'name': 'NET_22'
    }, {
        'cells': ('CELL_23', 'CELL_24'),
        'name': 'NET_23'
    }, {
        'cells': ('CELL_24', 'CELL_25'),
        'name': 'NET_24'
    }, {
        'cells': ('CELL_25', 'CELL_26'),
        'name': 'NET_25'
    }, {
        'cells': ('CELL_26', 'CELL_27'),
        'name': 'NET_26'
    }, {
        'cells': ('CELL_27', 'CELL_28'),
        'name': 'NET_27'
    }, {
        'cells': ('CELL_28', 'CELL_29'),
        'name': 'NET_28'
    }, {
        'cells': ('CELL_29', 'CELL_30'),
        'name': 'NET_29'
    }, {
        'cells': ('CELL_30', 'CELL_31'),
        'name': 'NET_30'
    }, {
        'cells': ('CELL_31', 'CELL_32'),
        'name': 'NET_31'
    }, {
        'cells': ('CELL_32', 'CELL_33'),
        'name': 'NET_32'
    }, {
        'cells': ('CELL_33', 'CELL_34'),
        'name': 'NET_33'
    }, {
        'cells': ('CELL_34', 'CELL_35'),
        'name': 'NET_34'
    }, {
        'cells': ('CELL_35', 'CELL_36'),
        'name': 'NET_35'
    }, {
        'cells': ('CELL_36', 'CELL_37'),
        'name': 'NET_36'
    }, {
        'cells': ('CELL_37', 'CELL_38'),
        'name': 'NET_37'
    }, {
        'cells': ('CELL_38', 'CELL_39'),
        'name': 'NET_38'
    }, {
        'cells': ('CELL_39', 'CELL_40'),
        'name': 'NET_39'
    }, {
        'cells': ('CELL_40', 'CELL_41'),
        'name': 'NET_40'
    }, {
        'cells': ('CELL_41', 'CELL_42'),
        'name': 'NET_41'
    }, {
        'cells': ('CELL_42', 'CELL_43'),
        'name': 'NET_42'
    }, {
        'cells': ('CELL_43', 'CELL_44'),
        'name': 'NET_43'
    }, {
        'cells': ('IO_0', 'CELL_44'),
        'name': 'NET_44'
    }, {
        'cells': ('IO_1', 'CELL_27'),
        'name': 'NET_45'
    }, {
        'cells': ('IO_2', 'CELL_21'),
        'name': 'NET_46'
    }, {
        'cells': ('IO_3', 'CELL_17'),
        'name': 'NET_47'
    }, {
        'cells': ('IO_4', 'CELL_9'),
        'name': 'NET_48'
    }]
}