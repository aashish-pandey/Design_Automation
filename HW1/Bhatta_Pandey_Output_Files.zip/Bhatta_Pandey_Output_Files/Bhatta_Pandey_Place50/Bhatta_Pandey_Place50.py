# Auto - generated optimized placement
data = {
    'grid_size': 9,
    'cells': {
        'CELL_0': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 4)
        },
        'CELL_1': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 4)
        },
        'CELL_10': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 3)
        },
        'CELL_11': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 3)
        },
        'CELL_12': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 6)
        },
        'CELL_13': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 8)
        },
        'CELL_14': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 5)
        },
        'CELL_15': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 5)
        },
        'CELL_16': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 4)
        },
        'CELL_17': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 2)
        },
        'CELL_18': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 2)
        },
        'CELL_19': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 3)
        },
        'CELL_2': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 6)
        },
        'CELL_20': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 1)
        },
        'CELL_21': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 7)
        },
        'CELL_22': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 6)
        },
        'CELL_23': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 0)
        },
        'CELL_24': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 4)
        },
        'CELL_25': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 3)
        },
        'CELL_26': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 1)
        },
        'CELL_27': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 8)
        },
        'CELL_28': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 4)
        },
        'CELL_29': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 8)
        },
        'CELL_3': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 6)
        },
        'CELL_30': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 8)
        },
        'CELL_31': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 0)
        },
        'CELL_32': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 5)
        },
        'CELL_33': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 4)
        },
        'CELL_34': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 3)
        },
        'CELL_35': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 5)
        },
        'CELL_36': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 6)
        },
        'CELL_37': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 2)
        },
        'CELL_38': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 2)
        },
        'CELL_39': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 7)
        },
        'CELL_4': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 2)
        },
        'CELL_40': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 2)
        },
        'CELL_41': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 2)
        },
        'CELL_42': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 5)
        },
        'CELL_43': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 7)
        },
        'CELL_44': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 4)
        },
        'CELL_5': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 0)
        },
        'CELL_6': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 2)
        },
        'CELL_7': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 7)
        },
        'CELL_8': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 2)
        },
        'CELL_9': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 8)
        },
        'IO_0': {
            'type': 'IO',
            'fixed': True,
            'position': (2, 8)
        },
        'IO_1': {
            'type': 'IO',
            'fixed': True,
            'position': (0, 0)
        },
        'IO_2': {
            'type': 'IO',
            'fixed': True,
            'position': (6, 0)
        },
        'IO_3': {
            'type': 'IO',
            'fixed': True,
            'position': (0, 5)
        },
        'IO_4': {
            'type': 'IO',
            'fixed': True,
            'position': (4, 0)
        }
    },
    'nets': [{
        'name': 'NET_0',
        'cells': ('IO_0', 'CELL_22')
    }, {
        'name': 'NET_1',
        'cells': ('IO_1', 'CELL_5')
    }, {
        'name': 'NET_10',
        'cells': ('CELL_2', 'CELL_44')
    }, {
        'name': 'NET_100',
        'cells': ('CELL_38', 'CELL_9')
    }, {
        'name': 'NET_101',
        'cells': ('CELL_23', 'CELL_5')
    }, {
        'name': 'NET_102',
        'cells': ('CELL_0', 'CELL_16')
    }, {
        'name': 'NET_103',
        'cells': ('CELL_42', 'CELL_36')
    }, {
        'name': 'NET_11',
        'cells': ('CELL_3', 'IO_2')
    }, {
        'name': 'NET_12',
        'cells': ('CELL_4', 'CELL_20')
    }, {
        'name': 'NET_13',
        'cells': ('CELL_4', 'CELL_41')
    }, {
        'name': 'NET_14',
        'cells': ('CELL_5', 'CELL_33')
    }, {
        'name': 'NET_15',
        'cells': ('CELL_6', 'CELL_17')
    }, {
        'name': 'NET_16',
        'cells': ('CELL_6', 'CELL_31')
    }, {
        'name': 'NET_17',
        'cells': ('CELL_7', 'CELL_13')
    }, {
        'name': 'NET_18',
        'cells': ('CELL_7', 'CELL_28')
    }, {
        'name': 'NET_19',
        'cells': ('CELL_8', 'CELL_11')
    }, {
        'name': 'NET_2',
        'cells': ('IO_2', 'IO_1')
    }, {
        'name': 'NET_20',
        'cells': ('CELL_8', 'IO_2')
    }, {
        'name': 'NET_21',
        'cells': ('CELL_9', 'CELL_15')
    }, {
        'name': 'NET_22',
        'cells': ('CELL_9', 'IO_0')
    }, {
        'name': 'NET_23',
        'cells': ('CELL_10', 'IO_4')
    }, {
        'name': 'NET_24',
        'cells': ('CELL_10', 'CELL_1')
    }, {
        'name': 'NET_25',
        'cells': ('CELL_11', 'CELL_34')
    }, {
        'name': 'NET_26',
        'cells': ('CELL_12', 'CELL_30')
    }, {
        'name': 'NET_27',
        'cells': ('CELL_12', 'IO_2')
    }, {
        'name': 'NET_28',
        'cells': ('CELL_13', 'CELL_7')
    }, {
        'name': 'NET_29',
        'cells': ('CELL_14', 'CELL_22')
    }, {
        'name': 'NET_3',
        'cells': ('IO_3', 'CELL_14')
    }, {
        'name': 'NET_30',
        'cells': ('CELL_15', 'CELL_13')
    }, {
        'name': 'NET_31',
        'cells': ('CELL_16', 'CELL_35')
    }, {
        'name': 'NET_32',
        'cells': ('CELL_16', 'CELL_11')
    }, {
        'name': 'NET_33',
        'cells': ('CELL_17', 'CELL_4')
    }, {
        'name': 'NET_34',
        'cells': ('CELL_18', 'CELL_40')
    }, {
        'name': 'NET_35',
        'cells': ('CELL_18', 'IO_2')
    }, {
        'name': 'NET_36',
        'cells': ('CELL_19', 'CELL_16')
    }, {
        'name': 'NET_37',
        'cells': ('CELL_19', 'CELL_15')
    }, {
        'name': 'NET_38',
        'cells': ('CELL_20', 'CELL_18')
    }, {
        'name': 'NET_39',
        'cells': ('CELL_21', 'CELL_3')
    }, {
        'name': 'NET_4',
        'cells': ('IO_4', 'CELL_23')
    }, {
        'name': 'NET_40',
        'cells': ('CELL_21', 'CELL_19')
    }, {
        'name': 'NET_41',
        'cells': ('CELL_23', 'CELL_19')
    }, {
        'name': 'NET_42',
        'cells': ('CELL_24', 'CELL_25')
    }, {
        'name': 'NET_43',
        'cells': ('CELL_24', 'CELL_29')
    }, {
        'name': 'NET_44',
        'cells': ('CELL_25', 'CELL_19')
    }, {
        'name': 'NET_45',
        'cells': ('CELL_26', 'CELL_37')
    }, {
        'name': 'NET_46',
        'cells': ('CELL_26', 'CELL_34')
    }, {
        'name': 'NET_47',
        'cells': ('CELL_27', 'CELL_39')
    }, {
        'name': 'NET_48',
        'cells': ('CELL_27', 'CELL_31')
    }, {
        'name': 'NET_49',
        'cells': ('CELL_28', 'CELL_1')
    }, {
        'name': 'NET_5',
        'cells': ('CELL_0', 'CELL_22')
    }, {
        'name': 'NET_50',
        'cells': ('CELL_29', 'CELL_35')
    }, {
        'name': 'NET_51',
        'cells': ('CELL_30', 'CELL_27')
    }, {
        'name': 'NET_52',
        'cells': ('CELL_32', 'CELL_12')
    }, {
        'name': 'NET_53',
        'cells': ('CELL_32', 'CELL_22')
    }, {
        'name': 'NET_54',
        'cells': ('CELL_33', 'CELL_36')
    }, {
        'name': 'NET_55',
        'cells': ('CELL_36', 'CELL_42')
    }, {
        'name': 'NET_56',
        'cells': ('CELL_37', 'CELL_41')
    }, {
        'name': 'NET_57',
        'cells': ('CELL_38', 'CELL_10')
    }, {
        'name': 'NET_58',
        'cells': ('CELL_38', 'CELL_14')
    }, {
        'name': 'NET_59',
        'cells': ('CELL_39', 'CELL_22')
    }, {
        'name': 'NET_6',
        'cells': ('CELL_0', 'CELL_3')
    }, {
        'name': 'NET_60',
        'cells': ('CELL_40', 'CELL_11')
    }, {
        'name': 'NET_61',
        'cells': ('CELL_42', 'CELL_28')
    }, {
        'name': 'NET_62',
        'cells': ('CELL_43', 'CELL_14')
    }, {
        'name': 'NET_63',
        'cells': ('CELL_43', 'CELL_30')
    }, {
        'name': 'NET_64',
        'cells': ('CELL_44', 'CELL_16')
    }, {
        'name': 'NET_65',
        'cells': ('IO_0', 'CELL_21')
    }, {
        'name': 'NET_66',
        'cells': ('CELL_32', 'CELL_15')
    }, {
        'name': 'NET_67',
        'cells': ('IO_1', 'CELL_19')
    }, {
        'name': 'NET_68',
        'cells': ('CELL_34', 'CELL_32')
    }, {
        'name': 'NET_69',
        'cells': ('CELL_35', 'CELL_3')
    }, {
        'name': 'NET_7',
        'cells': ('CELL_1', 'IO_2')
    }, {
        'name': 'NET_70',
        'cells': ('IO_3', 'CELL_35')
    }, {
        'name': 'NET_71',
        'cells': ('CELL_35', 'CELL_16')
    }, {
        'name': 'NET_72',
        'cells': ('CELL_24', 'CELL_17')
    }, {
        'name': 'NET_73',
        'cells': ('CELL_38', 'CELL_17')
    }, {
        'name': 'NET_74',
        'cells': ('CELL_33', 'CELL_40')
    }, {
        'name': 'NET_75',
        'cells': ('CELL_12', 'CELL_42')
    }, {
        'name': 'NET_76',
        'cells': ('CELL_26', 'IO_1')
    }, {
        'name': 'NET_77',
        'cells': ('CELL_32', 'IO_3')
    }, {
        'name': 'NET_78',
        'cells': ('CELL_38', 'IO_1')
    }, {
        'name': 'NET_79',
        'cells': ('CELL_18', 'CELL_11')
    }, {
        'name': 'NET_8',
        'cells': ('CELL_1', 'CELL_34')
    }, {
        'name': 'NET_80',
        'cells': ('CELL_35', 'CELL_24')
    }, {
        'name': 'NET_81',
        'cells': ('CELL_14', 'CELL_32')
    }, {
        'name': 'NET_82',
        'cells': ('CELL_33', 'CELL_15')
    }, {
        'name': 'NET_83',
        'cells': ('CELL_6', 'CELL_18')
    }, {
        'name': 'NET_84',
        'cells': ('CELL_6', 'CELL_15')
    }, {
        'name': 'NET_85',
        'cells': ('CELL_43', 'CELL_18')
    }, {
        'name': 'NET_86',
        'cells': ('CELL_33', 'CELL_11')
    }, {
        'name': 'NET_87',
        'cells': ('CELL_14', 'CELL_19')
    }, {
        'name': 'NET_88',
        'cells': ('CELL_1', 'CELL_44')
    }, {
        'name': 'NET_89',
        'cells': ('IO_1', 'CELL_31')
    }, {
        'name': 'NET_9',
        'cells': ('CELL_2', 'CELL_35')
    }, {
        'name': 'NET_90',
        'cells': ('CELL_38', 'CELL_42')
    }, {
        'name': 'NET_91',
        'cells': ('CELL_3', 'CELL_14')
    }, {
        'name': 'NET_92',
        'cells': ('CELL_27', 'CELL_9')
    }, {
        'name': 'NET_93',
        'cells': ('CELL_36', 'CELL_12')
    }, {
        'name': 'NET_94',
        'cells': ('CELL_10', 'CELL_15')
    }, {
        'name': 'NET_95',
        'cells': ('CELL_6', 'CELL_38')
    }, {
        'name': 'NET_96',
        'cells': ('CELL_22', 'CELL_36')
    }, {
        'name': 'NET_97',
        'cells': ('CELL_39', 'CELL_1')
    }, {
        'name': 'NET_98',
        'cells': ('CELL_1', 'CELL_33')
    }, {
        'name': 'NET_99',
        'cells': ('CELL_15', 'CELL_16')
    }]
}