# Auto - generated optimized placement
data = {
    'grid_size': 13,
    'cells': {
        'CELL_0': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 9)
        },
        'CELL_1': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 2)
        },
        'CELL_10': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 3)
        },
        'CELL_11': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 12)
        },
        'CELL_12': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 1)
        },
        'CELL_13': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 12)
        },
        'CELL_14': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 2)
        },
        'CELL_15': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 1)
        },
        'CELL_16': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 4)
        },
        'CELL_17': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 11)
        },
        'CELL_18': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 8)
        },
        'CELL_19': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 3)
        },
        'CELL_2': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 4)
        },
        'CELL_20': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 8)
        },
        'CELL_21': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 9)
        },
        'CELL_22': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 1)
        },
        'CELL_23': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 10)
        },
        'CELL_24': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 8)
        },
        'CELL_25': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 10)
        },
        'CELL_26': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 5)
        },
        'CELL_27': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 3)
        },
        'CELL_28': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 12)
        },
        'CELL_29': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 10)
        },
        'CELL_3': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 5)
        },
        'CELL_30': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 6)
        },
        'CELL_31': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 2)
        },
        'CELL_32': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 1)
        },
        'CELL_33': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 5)
        },
        'CELL_34': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 7)
        },
        'CELL_35': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 10)
        },
        'CELL_36': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 9)
        },
        'CELL_37': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 1)
        },
        'CELL_38': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 8)
        },
        'CELL_39': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 3)
        },
        'CELL_4': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 3)
        },
        'CELL_40': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 7)
        },
        'CELL_41': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 11)
        },
        'CELL_42': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 10)
        },
        'CELL_43': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 6)
        },
        'CELL_44': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 7)
        },
        'CELL_45': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 11)
        },
        'CELL_46': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 0)
        },
        'CELL_47': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 12)
        },
        'CELL_48': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 2)
        },
        'CELL_49': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 1)
        },
        'CELL_5': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 6)
        },
        'CELL_50': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 11)
        },
        'CELL_51': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 9)
        },
        'CELL_52': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 11)
        },
        'CELL_53': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 9)
        },
        'CELL_54': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 8)
        },
        'CELL_55': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 0)
        },
        'CELL_56': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 6)
        },
        'CELL_57': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 7)
        },
        'CELL_58': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 6)
        },
        'CELL_59': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 8)
        },
        'CELL_6': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 0)
        },
        'CELL_60': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 4)
        },
        'CELL_61': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 5)
        },
        'CELL_62': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 9)
        },
        'CELL_63': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 11)
        },
        'CELL_64': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 12)
        },
        'CELL_65': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 5)
        },
        'CELL_66': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 9)
        },
        'CELL_67': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (7, 12)
        },
        'CELL_68': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 3)
        },
        'CELL_69': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 8)
        },
        'CELL_7': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 8)
        },
        'CELL_70': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 10)
        },
        'CELL_71': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 0)
        },
        'CELL_72': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (8, 11)
        },
        'CELL_73': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 12)
        },
        'CELL_74': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 8)
        },
        'CELL_75': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 3)
        },
        'CELL_76': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 12)
        },
        'CELL_77': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 5)
        },
        'CELL_78': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (3, 5)
        },
        'CELL_79': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 6)
        },
        'CELL_8': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (2, 10)
        },
        'CELL_80': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (1, 12)
        },
        'CELL_81': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 0)
        },
        'CELL_82': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (9, 9)
        },
        'CELL_83': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (0, 7)
        },
        'CELL_84': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 5)
        },
        'CELL_85': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (12, 4)
        },
        'CELL_86': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (5, 6)
        },
        'CELL_87': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (10, 9)
        },
        'CELL_88': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (4, 0)
        },
        'CELL_89': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (6, 3)
        },
        'CELL_9': {
            'type': 'MOVABLE',
            'fixed': False,
            'position': (11, 2)
        },
        'IO_0': {
            'type': 'IO',
            'fixed': True,
            'position': (0, 0)
        },
        'IO_1': {
            'type': 'IO',
            'fixed': True,
            'position': (12, 11)
        },
        'IO_2': {
            'type': 'IO',
            'fixed': True,
            'position': (0, 2)
        },
        'IO_3': {
            'type': 'IO',
            'fixed': True,
            'position': (5, 0)
        },
        'IO_4': {
            'type': 'IO',
            'fixed': True,
            'position': (11, 0)
        },
        'IO_5': {
            'type': 'IO',
            'fixed': True,
            'position': (7, 0)
        },
        'IO_6': {
            'type': 'IO',
            'fixed': True,
            'position': (2, 0)
        },
        'IO_7': {
            'type': 'IO',
            'fixed': True,
            'position': (6, 0)
        },
        'IO_8': {
            'type': 'IO',
            'fixed': True,
            'position': (12, 7)
        },
        'IO_9': {
            'type': 'IO',
            'fixed': True,
            'position': (0, 6)
        }
    },
    'nets': [{
        'name': 'NET_0',
        'cells': ('IO_0', 'CELL_66')
    }, {
        'name': 'NET_1',
        'cells': ('IO_1', 'CELL_67')
    }, {
        'name': 'NET_10',
        'cells': ('CELL_0', 'CELL_24')
    }, {
        'name': 'NET_100',
        'cells': ('CELL_62', 'IO_8')
    }, {
        'name': 'NET_101',
        'cells': ('CELL_64', 'CELL_66')
    }, {
        'name': 'NET_102',
        'cells': ('CELL_65', 'CELL_26')
    }, {
        'name': 'NET_103',
        'cells': ('CELL_65', 'CELL_5')
    }, {
        'name': 'NET_104',
        'cells': ('CELL_68', 'CELL_21')
    }, {
        'name': 'NET_105',
        'cells': ('CELL_68', 'IO_5')
    }, {
        'name': 'NET_106',
        'cells': ('CELL_69', 'IO_4')
    }, {
        'name': 'NET_107',
        'cells': ('CELL_69', 'CELL_79')
    }, {
        'name': 'NET_108',
        'cells': ('CELL_71', 'CELL_55')
    }, {
        'name': 'NET_109',
        'cells': ('CELL_71', 'CELL_15')
    }, {
        'name': 'NET_11',
        'cells': ('CELL_0', 'CELL_29')
    }, {
        'name': 'NET_110',
        'cells': ('CELL_72', 'CELL_45')
    }, {
        'name': 'NET_111',
        'cells': ('CELL_73', 'CELL_63')
    }, {
        'name': 'NET_112',
        'cells': ('CELL_75', 'IO_6')
    }, {
        'name': 'NET_113',
        'cells': ('CELL_76', 'IO_1')
    }, {
        'name': 'NET_114',
        'cells': ('CELL_76', 'CELL_51')
    }, {
        'name': 'NET_115',
        'cells': ('CELL_78', 'CELL_86')
    }, {
        'name': 'NET_116',
        'cells': ('CELL_79', 'CELL_5')
    }, {
        'name': 'NET_117',
        'cells': ('CELL_80', 'CELL_11')
    }, {
        'name': 'NET_118',
        'cells': ('CELL_81', 'CELL_54')
    }, {
        'name': 'NET_119',
        'cells': ('CELL_81', 'CELL_28')
    }, {
        'name': 'NET_12',
        'cells': ('CELL_1', 'CELL_39')
    }, {
        'name': 'NET_120',
        'cells': ('CELL_82', 'CELL_20')
    }, {
        'name': 'NET_121',
        'cells': ('CELL_83', 'CELL_74')
    }, {
        'name': 'NET_122',
        'cells': ('CELL_83', 'IO_2')
    }, {
        'name': 'NET_123',
        'cells': ('CELL_84', 'CELL_57')
    }, {
        'name': 'NET_124',
        'cells': ('CELL_84', 'CELL_58')
    }, {
        'name': 'NET_125',
        'cells': ('CELL_87', 'CELL_42')
    }, {
        'name': 'NET_126',
        'cells': ('CELL_88', 'IO_6')
    }, {
        'name': 'NET_127',
        'cells': ('CELL_89', 'CELL_68')
    }, {
        'name': 'NET_128',
        'cells': ('CELL_4', 'CELL_33')
    }, {
        'name': 'NET_129',
        'cells': ('CELL_6', 'CELL_22')
    }, {
        'name': 'NET_13',
        'cells': ('CELL_1', 'CELL_4')
    }, {
        'name': 'NET_130',
        'cells': ('CELL_59', 'CELL_51')
    }, {
        'name': 'NET_131',
        'cells': ('IO_7', 'CELL_35')
    }, {
        'name': 'NET_132',
        'cells': ('CELL_18', 'CELL_15')
    }, {
        'name': 'NET_133',
        'cells': ('CELL_5', 'CELL_58')
    }, {
        'name': 'NET_134',
        'cells': ('CELL_5', 'CELL_11')
    }, {
        'name': 'NET_135',
        'cells': ('CELL_20', 'CELL_25')
    }, {
        'name': 'NET_136',
        'cells': ('CELL_6', 'IO_0')
    }, {
        'name': 'NET_137',
        'cells': ('CELL_52', 'CELL_70')
    }, {
        'name': 'NET_138',
        'cells': ('CELL_63', 'CELL_41')
    }, {
        'name': 'NET_139',
        'cells': ('IO_6', 'CELL_86')
    }, {
        'name': 'NET_14',
        'cells': ('CELL_2', 'CELL_89')
    }, {
        'name': 'NET_140',
        'cells': ('CELL_24', 'CELL_21')
    }, {
        'name': 'NET_141',
        'cells': ('CELL_24', 'CELL_69')
    }, {
        'name': 'NET_142',
        'cells': ('CELL_57', 'CELL_56')
    }, {
        'name': 'NET_143',
        'cells': ('CELL_44', 'IO_6')
    }, {
        'name': 'NET_144',
        'cells': ('CELL_50', 'CELL_31')
    }, {
        'name': 'NET_145',
        'cells': ('CELL_89', 'IO_0')
    }, {
        'name': 'NET_146',
        'cells': ('IO_7', 'CELL_89')
    }, {
        'name': 'NET_147',
        'cells': ('CELL_6', 'IO_5')
    }, {
        'name': 'NET_148',
        'cells': ('CELL_5', 'IO_6')
    }, {
        'name': 'NET_149',
        'cells': ('IO_8', 'CELL_51')
    }, {
        'name': 'NET_15',
        'cells': ('CELL_2', 'IO_3')
    }, {
        'name': 'NET_150',
        'cells': ('IO_4', 'CELL_81')
    }, {
        'name': 'NET_151',
        'cells': ('CELL_1', 'CELL_55')
    }, {
        'name': 'NET_152',
        'cells': ('CELL_54', 'CELL_52')
    }, {
        'name': 'NET_153',
        'cells': ('CELL_30', 'CELL_10')
    }, {
        'name': 'NET_154',
        'cells': ('CELL_30', 'IO_9')
    }, {
        'name': 'NET_155',
        'cells': ('CELL_34', 'CELL_39')
    }, {
        'name': 'NET_156',
        'cells': ('CELL_72', 'CELL_39')
    }, {
        'name': 'NET_157',
        'cells': ('CELL_65', 'CELL_28')
    }, {
        'name': 'NET_158',
        'cells': ('CELL_36', 'CELL_23')
    }, {
        'name': 'NET_159',
        'cells': ('CELL_14', 'CELL_32')
    }, {
        'name': 'NET_16',
        'cells': ('CELL_3', 'CELL_63')
    }, {
        'name': 'NET_160',
        'cells': ('CELL_44', 'CELL_5')
    }, {
        'name': 'NET_161',
        'cells': ('CELL_6', 'CELL_61')
    }, {
        'name': 'NET_162',
        'cells': ('IO_0', 'CELL_81')
    }, {
        'name': 'NET_163',
        'cells': ('CELL_82', 'CELL_38')
    }, {
        'name': 'NET_164',
        'cells': ('CELL_0', 'CELL_62')
    }, {
        'name': 'NET_165',
        'cells': ('CELL_12', 'IO_5')
    }, {
        'name': 'NET_166',
        'cells': ('CELL_37', 'CELL_48')
    }, {
        'name': 'NET_167',
        'cells': ('CELL_67', 'CELL_73')
    }, {
        'name': 'NET_168',
        'cells': ('CELL_59', 'CELL_38')
    }, {
        'name': 'NET_169',
        'cells': ('CELL_71', 'IO_5')
    }, {
        'name': 'NET_17',
        'cells': ('CELL_3', 'CELL_78')
    }, {
        'name': 'NET_170',
        'cells': ('CELL_69', 'CELL_45')
    }, {
        'name': 'NET_171',
        'cells': ('IO_6', 'CELL_37')
    }, {
        'name': 'NET_172',
        'cells': ('CELL_70', 'CELL_53')
    }, {
        'name': 'NET_173',
        'cells': ('CELL_87', 'CELL_79')
    }, {
        'name': 'NET_174',
        'cells': ('CELL_30', 'CELL_43')
    }, {
        'name': 'NET_175',
        'cells': ('CELL_78', 'CELL_43')
    }, {
        'name': 'NET_176',
        'cells': ('CELL_48', 'IO_2')
    }, {
        'name': 'NET_177',
        'cells': ('CELL_21', 'CELL_17')
    }, {
        'name': 'NET_178',
        'cells': ('CELL_58', 'CELL_24')
    }, {
        'name': 'NET_179',
        'cells': ('CELL_78', 'CELL_65')
    }, {
        'name': 'NET_18',
        'cells': ('CELL_4', 'CELL_85')
    }, {
        'name': 'NET_180',
        'cells': ('IO_9', 'CELL_44')
    }, {
        'name': 'NET_181',
        'cells': ('CELL_18', 'CELL_44')
    }, {
        'name': 'NET_182',
        'cells': ('CELL_6', 'IO_3')
    }, {
        'name': 'NET_183',
        'cells': ('CELL_31', 'CELL_37')
    }, {
        'name': 'NET_184',
        'cells': ('CELL_61', 'CELL_23')
    }, {
        'name': 'NET_185',
        'cells': ('CELL_5', 'CELL_49')
    }, {
        'name': 'NET_186',
        'cells': ('CELL_78', 'CELL_5')
    }, {
        'name': 'NET_187',
        'cells': ('CELL_83', 'CELL_74')
    }, {
        'name': 'NET_188',
        'cells': ('CELL_57', 'CELL_38')
    }, {
        'name': 'NET_189',
        'cells': ('CELL_75', 'CELL_3')
    }, {
        'name': 'NET_19',
        'cells': ('CELL_5', 'CELL_7')
    }, {
        'name': 'NET_190',
        'cells': ('CELL_83', 'CELL_30')
    }, {
        'name': 'NET_191',
        'cells': ('CELL_62', 'CELL_58')
    }, {
        'name': 'NET_192',
        'cells': ('CELL_3', 'CELL_65')
    }, {
        'name': 'NET_193',
        'cells': ('CELL_81', 'IO_0')
    }, {
        'name': 'NET_194',
        'cells': ('CELL_50', 'CELL_8')
    }, {
        'name': 'NET_195',
        'cells': ('CELL_20', 'CELL_89')
    }, {
        'name': 'NET_196',
        'cells': ('CELL_39', 'IO_5')
    }, {
        'name': 'NET_197',
        'cells': ('CELL_57', 'CELL_1')
    }, {
        'name': 'NET_198',
        'cells': ('CELL_62', 'CELL_2')
    }, {
        'name': 'NET_199',
        'cells': ('CELL_74', 'CELL_38')
    }, {
        'name': 'NET_2',
        'cells': ('IO_2', 'CELL_31')
    }, {
        'name': 'NET_20',
        'cells': ('CELL_5', 'CELL_30')
    }, {
        'name': 'NET_200',
        'cells': ('CELL_12', 'IO_3')
    }, {
        'name': 'NET_201',
        'cells': ('CELL_33', 'CELL_5')
    }, {
        'name': 'NET_202',
        'cells': ('IO_3', 'CELL_4')
    }, {
        'name': 'NET_203',
        'cells': ('CELL_76', 'CELL_51')
    }, {
        'name': 'NET_204',
        'cells': ('CELL_79', 'CELL_26')
    }, {
        'name': 'NET_205',
        'cells': ('CELL_64', 'CELL_28')
    }, {
        'name': 'NET_206',
        'cells': ('CELL_1', 'IO_4')
    }, {
        'name': 'NET_207',
        'cells': ('CELL_88', 'CELL_62')
    }, {
        'name': 'NET_208',
        'cells': ('CELL_55', 'CELL_57')
    }, {
        'name': 'NET_209',
        'cells': ('CELL_81', 'CELL_20')
    }, {
        'name': 'NET_21',
        'cells': ('CELL_6', 'CELL_55')
    }, {
        'name': 'NET_210',
        'cells': ('CELL_3', 'CELL_60')
    }, {
        'name': 'NET_211',
        'cells': ('CELL_85', 'CELL_2')
    }, {
        'name': 'NET_212',
        'cells': ('CELL_60', 'IO_7')
    }, {
        'name': 'NET_213',
        'cells': ('CELL_60', 'CELL_31')
    }, {
        'name': 'NET_214',
        'cells': ('CELL_62', 'CELL_13')
    }, {
        'name': 'NET_215',
        'cells': ('IO_9', 'CELL_20')
    }, {
        'name': 'NET_216',
        'cells': ('CELL_13', 'CELL_72')
    }, {
        'name': 'NET_217',
        'cells': ('CELL_21', 'CELL_48')
    }, {
        'name': 'NET_218',
        'cells': ('CELL_68', 'CELL_79')
    }, {
        'name': 'NET_219',
        'cells': ('CELL_86', 'CELL_40')
    }, {
        'name': 'NET_22',
        'cells': ('CELL_6', 'CELL_19')
    }, {
        'name': 'NET_220',
        'cells': ('CELL_22', 'CELL_37')
    }, {
        'name': 'NET_221',
        'cells': ('CELL_66', 'CELL_40')
    }, {
        'name': 'NET_222',
        'cells': ('CELL_34', 'CELL_61')
    }, {
        'name': 'NET_223',
        'cells': ('CELL_43', 'CELL_0')
    }, {
        'name': 'NET_224',
        'cells': ('CELL_38', 'CELL_54')
    }, {
        'name': 'NET_225',
        'cells': ('CELL_20', 'CELL_42')
    }, {
        'name': 'NET_226',
        'cells': ('CELL_85', 'CELL_10')
    }, {
        'name': 'NET_227',
        'cells': ('CELL_43', 'CELL_78')
    }, {
        'name': 'NET_228',
        'cells': ('CELL_62', 'CELL_86')
    }, {
        'name': 'NET_229',
        'cells': ('CELL_64', 'CELL_76')
    }, {
        'name': 'NET_23',
        'cells': ('CELL_7', 'CELL_74')
    }, {
        'name': 'NET_230',
        'cells': ('CELL_56', 'CELL_77')
    }, {
        'name': 'NET_231',
        'cells': ('CELL_51', 'CELL_9')
    }, {
        'name': 'NET_232',
        'cells': ('CELL_72', 'CELL_41')
    }, {
        'name': 'NET_233',
        'cells': ('CELL_9', 'CELL_10')
    }, {
        'name': 'NET_234',
        'cells': ('CELL_2', 'CELL_53')
    }, {
        'name': 'NET_235',
        'cells': ('CELL_85', 'CELL_51')
    }, {
        'name': 'NET_236',
        'cells': ('CELL_79', 'CELL_56')
    }, {
        'name': 'NET_237',
        'cells': ('CELL_46', 'CELL_65')
    }, {
        'name': 'NET_24',
        'cells': ('CELL_8', 'CELL_25')
    }, {
        'name': 'NET_25',
        'cells': ('CELL_8', 'CELL_21')
    }, {
        'name': 'NET_26',
        'cells': ('CELL_9', 'CELL_32')
    }, {
        'name': 'NET_27',
        'cells': ('CELL_9', 'CELL_14')
    }, {
        'name': 'NET_28',
        'cells': ('CELL_10', 'CELL_77')
    }, {
        'name': 'NET_29',
        'cells': ('CELL_10', 'CELL_46')
    }, {
        'name': 'NET_3',
        'cells': ('IO_3', 'CELL_13')
    }, {
        'name': 'NET_30',
        'cells': ('CELL_11', 'CELL_74')
    }, {
        'name': 'NET_31',
        'cells': ('CELL_11', 'CELL_80')
    }, {
        'name': 'NET_32',
        'cells': ('CELL_12', 'CELL_2')
    }, {
        'name': 'NET_33',
        'cells': ('CELL_12', 'CELL_3')
    }, {
        'name': 'NET_34',
        'cells': ('CELL_13', 'CELL_67')
    }, {
        'name': 'NET_35',
        'cells': ('CELL_15', 'CELL_32')
    }, {
        'name': 'NET_36',
        'cells': ('CELL_15', 'CELL_33')
    }, {
        'name': 'NET_37',
        'cells': ('CELL_16', 'CELL_77')
    }, {
        'name': 'NET_38',
        'cells': ('CELL_16', 'CELL_19')
    }, {
        'name': 'NET_39',
        'cells': ('CELL_17', 'CELL_47')
    }, {
        'name': 'NET_4',
        'cells': ('IO_4', 'CELL_37')
    }, {
        'name': 'NET_40',
        'cells': ('CELL_17', 'CELL_11')
    }, {
        'name': 'NET_41',
        'cells': ('CELL_18', 'CELL_0')
    }, {
        'name': 'NET_42',
        'cells': ('CELL_18', 'CELL_34')
    }, {
        'name': 'NET_43',
        'cells': ('CELL_20', 'CELL_85')
    }, {
        'name': 'NET_44',
        'cells': ('CELL_20', 'CELL_74')
    }, {
        'name': 'NET_45',
        'cells': ('CELL_21', 'CELL_17')
    }, {
        'name': 'NET_46',
        'cells': ('CELL_22', 'CELL_63')
    }, {
        'name': 'NET_47',
        'cells': ('CELL_22', 'CELL_48')
    }, {
        'name': 'NET_48',
        'cells': ('CELL_23', 'CELL_25')
    }, {
        'name': 'NET_49',
        'cells': ('CELL_23', 'CELL_18')
    }, {
        'name': 'NET_5',
        'cells': ('IO_5', 'CELL_14')
    }, {
        'name': 'NET_50',
        'cells': ('CELL_24', 'CELL_5')
    }, {
        'name': 'NET_51',
        'cells': ('CELL_26', 'IO_4')
    }, {
        'name': 'NET_52',
        'cells': ('CELL_26', 'CELL_58')
    }, {
        'name': 'NET_53',
        'cells': ('CELL_27', 'CELL_14')
    }, {
        'name': 'NET_54',
        'cells': ('CELL_27', 'CELL_31')
    }, {
        'name': 'NET_55',
        'cells': ('CELL_28', 'CELL_64')
    }, {
        'name': 'NET_56',
        'cells': ('CELL_28', 'CELL_13')
    }, {
        'name': 'NET_57',
        'cells': ('CELL_29', 'CELL_25')
    }, {
        'name': 'NET_58',
        'cells': ('CELL_30', 'CELL_34')
    }, {
        'name': 'NET_59',
        'cells': ('CELL_33', 'CELL_73')
    }, {
        'name': 'NET_6',
        'cells': ('IO_6', 'CELL_31')
    }, {
        'name': 'NET_60',
        'cells': ('CELL_35', 'CELL_0')
    }, {
        'name': 'NET_61',
        'cells': ('CELL_35', 'CELL_70')
    }, {
        'name': 'NET_62',
        'cells': ('CELL_36', 'CELL_34')
    }, {
        'name': 'NET_63',
        'cells': ('CELL_36', 'CELL_66')
    }, {
        'name': 'NET_64',
        'cells': ('CELL_37', 'CELL_6')
    }, {
        'name': 'NET_65',
        'cells': ('CELL_38', 'CELL_44')
    }, {
        'name': 'NET_66',
        'cells': ('CELL_39', 'CELL_27')
    }, {
        'name': 'NET_67',
        'cells': ('CELL_40', 'CELL_57')
    }, {
        'name': 'NET_68',
        'cells': ('CELL_40', 'CELL_24')
    }, {
        'name': 'NET_69',
        'cells': ('CELL_41', 'CELL_50')
    }, {
        'name': 'NET_7',
        'cells': ('IO_7', 'CELL_88')
    }, {
        'name': 'NET_70',
        'cells': ('CELL_41', 'CELL_34')
    }, {
        'name': 'NET_71',
        'cells': ('CELL_42', 'CELL_72')
    }, {
        'name': 'NET_72',
        'cells': ('CELL_42', 'CELL_44')
    }, {
        'name': 'NET_73',
        'cells': ('CELL_43', 'CELL_27')
    }, {
        'name': 'NET_74',
        'cells': ('CELL_43', 'CELL_44')
    }, {
        'name': 'NET_75',
        'cells': ('CELL_45', 'CELL_63')
    }, {
        'name': 'NET_76',
        'cells': ('CELL_45', 'CELL_42')
    }, {
        'name': 'NET_77',
        'cells': ('CELL_46', 'IO_4')
    }, {
        'name': 'NET_78',
        'cells': ('CELL_47', 'CELL_42')
    }, {
        'name': 'NET_79',
        'cells': ('CELL_48', 'CELL_9')
    }, {
        'name': 'NET_8',
        'cells': ('IO_8', 'CELL_38')
    }, {
        'name': 'NET_80',
        'cells': ('CELL_49', 'CELL_15')
    }, {
        'name': 'NET_81',
        'cells': ('CELL_49', 'IO_0')
    }, {
        'name': 'NET_82',
        'cells': ('CELL_50', 'CELL_52')
    }, {
        'name': 'NET_83',
        'cells': ('CELL_51', 'CELL_70')
    }, {
        'name': 'NET_84',
        'cells': ('CELL_51', 'CELL_56')
    }, {
        'name': 'NET_85',
        'cells': ('CELL_52', 'CELL_45')
    }, {
        'name': 'NET_86',
        'cells': ('CELL_53', 'CELL_62')
    }, {
        'name': 'NET_87',
        'cells': ('CELL_53', 'CELL_82')
    }, {
        'name': 'NET_88',
        'cells': ('CELL_54', 'CELL_18')
    }, {
        'name': 'NET_89',
        'cells': ('CELL_54', 'IO_4')
    }, {
        'name': 'NET_9',
        'cells': ('IO_9', 'CELL_67')
    }, {
        'name': 'NET_90',
        'cells': ('CELL_55', 'CELL_86')
    }, {
        'name': 'NET_91',
        'cells': ('CELL_56', 'CELL_48')
    }, {
        'name': 'NET_92',
        'cells': ('CELL_57', 'CELL_87')
    }, {
        'name': 'NET_93',
        'cells': ('CELL_58', 'CELL_75')
    }, {
        'name': 'NET_94',
        'cells': ('CELL_59', 'CELL_86')
    }, {
        'name': 'NET_95',
        'cells': ('CELL_59', 'CELL_56')
    }, {
        'name': 'NET_96',
        'cells': ('CELL_60', 'CELL_26')
    }, {
        'name': 'NET_97',
        'cells': ('CELL_60', 'CELL_59')
    }, {
        'name': 'NET_98',
        'cells': ('CELL_61', 'CELL_33')
    }, {
        'name': 'NET_99',
        'cells': ('CELL_61', 'CELL_19')
    }]
}