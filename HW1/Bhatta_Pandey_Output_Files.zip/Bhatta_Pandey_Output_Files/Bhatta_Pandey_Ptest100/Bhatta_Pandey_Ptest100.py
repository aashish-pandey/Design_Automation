# Auto - generated optimized placement
data = {
    'cells': {
        'CELL_0': {
            'fixed': False,
            'position': (11, 1),
            'type': 'MOVABLE'
        },
        'CELL_1': {
            'fixed': False,
            'position': (12, 1),
            'type': 'MOVABLE'
        },
        'CELL_10': {
            'fixed': False,
            'position': (6, 8),
            'type': 'MOVABLE'
        },
        'CELL_11': {
            'fixed': False,
            'position': (5, 8),
            'type': 'MOVABLE'
        },
        'CELL_12': {
            'fixed': False,
            'position': (3, 8),
            'type': 'MOVABLE'
        },
        'CELL_13': {
            'fixed': False,
            'position': (1, 10),
            'type': 'MOVABLE'
        },
        'CELL_14': {
            'fixed': False,
            'position': (1, 11),
            'type': 'MOVABLE'
        },
        'CELL_15': {
            'fixed': False,
            'position': (1, 12),
            'type': 'MOVABLE'
        },
        'CELL_16': {
            'fixed': False,
            'position': (0, 11),
            'type': 'MOVABLE'
        },
        'CELL_17': {
            'fixed': False,
            'position': (0, 10),
            'type': 'MOVABLE'
        },
        'CELL_18': {
            'fixed': False,
            'position': (0, 9),
            'type': 'MOVABLE'
        },
        'CELL_19': {
            'fixed': False,
            'position': (0, 8),
            'type': 'MOVABLE'
        },
        'CELL_2': {
            'fixed': False,
            'position': (12, 2),
            'type': 'MOVABLE'
        },
        'CELL_20': {
            'fixed': False,
            'position': (0, 7),
            'type': 'MOVABLE'
        },
        'CELL_21': {
            'fixed': False,
            'position': (0, 6),
            'type': 'MOVABLE'
        },
        'CELL_22': {
            'fixed': False,
            'position': (0, 4),
            'type': 'MOVABLE'
        },
        'CELL_23': {
            'fixed': False,
            'position': (0, 3),
            'type': 'MOVABLE'
        },
        'CELL_24': {
            'fixed': False,
            'position': (1, 3),
            'type': 'MOVABLE'
        },
        'CELL_25': {
            'fixed': False,
            'position': (3, 4),
            'type': 'MOVABLE'
        },
        'CELL_26': {
            'fixed': False,
            'position': (3, 6),
            'type': 'MOVABLE'
        },
        'CELL_27': {
            'fixed': False,
            'position': (5, 6),
            'type': 'MOVABLE'
        },
        'CELL_28': {
            'fixed': False,
            'position': (5, 4),
            'type': 'MOVABLE'
        },
        'CELL_29': {
            'fixed': False,
            'position': (5, 5),
            'type': 'MOVABLE'
        },
        'CELL_3': {
            'fixed': False,
            'position': (12, 3),
            'type': 'MOVABLE'
        },
        'CELL_30': {
            'fixed': False,
            'position': (6, 5),
            'type': 'MOVABLE'
        },
        'CELL_31': {
            'fixed': False,
            'position': (7, 3),
            'type': 'MOVABLE'
        },
        'CELL_32': {
            'fixed': False,
            'position': (8, 3),
            'type': 'MOVABLE'
        },
        'CELL_33': {
            'fixed': False,
            'position': (10, 2),
            'type': 'MOVABLE'
        },
        'CELL_34': {
            'fixed': False,
            'position': (10, 1),
            'type': 'MOVABLE'
        },
        'CELL_35': {
            'fixed': False,
            'position': (10, 0),
            'type': 'MOVABLE'
        },
        'CELL_36': {
            'fixed': False,
            'position': (9, 0),
            'type': 'MOVABLE'
        },
        'CELL_37': {
            'fixed': False,
            'position': (8, 0),
            'type': 'MOVABLE'
        },
        'CELL_38': {
            'fixed': False,
            'position': (11, 0),
            'type': 'MOVABLE'
        },
        'CELL_39': {
            'fixed': False,
            'position': (12, 0),
            'type': 'MOVABLE'
        },
        'CELL_4': {
            'fixed': False,
            'position': (12, 4),
            'type': 'MOVABLE'
        },
        'CELL_40': {
            'fixed': False,
            'position': (12, 7),
            'type': 'MOVABLE'
        },
        'CELL_41': {
            'fixed': False,
            'position': (12, 8),
            'type': 'MOVABLE'
        },
        'CELL_42': {
            'fixed': False,
            'position': (12, 9),
            'type': 'MOVABLE'
        },
        'CELL_43': {
            'fixed': False,
            'position': (12, 10),
            'type': 'MOVABLE'
        },
        'CELL_44': {
            'fixed': False,
            'position': (11, 10),
            'type': 'MOVABLE'
        },
        'CELL_45': {
            'fixed': False,
            'position': (8, 10),
            'type': 'MOVABLE'
        },
        'CELL_46': {
            'fixed': False,
            'position': (6, 12),
            'type': 'MOVABLE'
        },
        'CELL_47': {
            'fixed': False,
            'position': (7, 11),
            'type': 'MOVABLE'
        },
        'CELL_48': {
            'fixed': False,
            'position': (8, 11),
            'type': 'MOVABLE'
        },
        'CELL_49': {
            'fixed': False,
            'position': (9, 11),
            'type': 'MOVABLE'
        },
        'CELL_5': {
            'fixed': False,
            'position': (12, 5),
            'type': 'MOVABLE'
        },
        'CELL_50': {
            'fixed': False,
            'position': (10, 11),
            'type': 'MOVABLE'
        },
        'CELL_51': {
            'fixed': False,
            'position': (11, 11),
            'type': 'MOVABLE'
        },
        'CELL_52': {
            'fixed': False,
            'position': (12, 11),
            'type': 'MOVABLE'
        },
        'CELL_53': {
            'fixed': False,
            'position': (12, 12),
            'type': 'MOVABLE'
        },
        'CELL_54': {
            'fixed': False,
            'position': (11, 12),
            'type': 'MOVABLE'
        },
        'CELL_55': {
            'fixed': False,
            'position': (10, 12),
            'type': 'MOVABLE'
        },
        'CELL_56': {
            'fixed': False,
            'position': (9, 12),
            'type': 'MOVABLE'
        },
        'CELL_57': {
            'fixed': False,
            'position': (5, 12),
            'type': 'MOVABLE'
        },
        'CELL_58': {
            'fixed': False,
            'position': (4, 12),
            'type': 'MOVABLE'
        },
        'CELL_59': {
            'fixed': False,
            'position': (4, 11),
            'type': 'MOVABLE'
        },
        'CELL_6': {
            'fixed': False,
            'position': (11, 5),
            'type': 'MOVABLE'
        },
        'CELL_60': {
            'fixed': False,
            'position': (3, 11),
            'type': 'MOVABLE'
        },
        'CELL_61': {
            'fixed': False,
            'position': (2, 11),
            'type': 'MOVABLE'
        },
        'CELL_62': {
            'fixed': False,
            'position': (2, 10),
            'type': 'MOVABLE'
        },
        'CELL_63': {
            'fixed': False,
            'position': (1, 9),
            'type': 'MOVABLE'
        },
        'CELL_64': {
            'fixed': False,
            'position': (1, 7),
            'type': 'MOVABLE'
        },
        'CELL_65': {
            'fixed': False,
            'position': (2, 7),
            'type': 'MOVABLE'
        },
        'CELL_66': {
            'fixed': False,
            'position': (2, 9),
            'type': 'MOVABLE'
        },
        'CELL_67': {
            'fixed': False,
            'position': (3, 9),
            'type': 'MOVABLE'
        },
        'CELL_68': {
            'fixed': False,
            'position': (3, 10),
            'type': 'MOVABLE'
        },
        'CELL_69': {
            'fixed': False,
            'position': (5, 10),
            'type': 'MOVABLE'
        },
        'CELL_7': {
            'fixed': False,
            'position': (8, 5),
            'type': 'MOVABLE'
        },
        'CELL_70': {
            'fixed': False,
            'position': (7, 9),
            'type': 'MOVABLE'
        },
        'CELL_71': {
            'fixed': False,
            'position': (8, 9),
            'type': 'MOVABLE'
        },
        'CELL_72': {
            'fixed': False,
            'position': (11, 8),
            'type': 'MOVABLE'
        },
        'CELL_73': {
            'fixed': False,
            'position': (11, 7),
            'type': 'MOVABLE'
        },
        'CELL_74': {
            'fixed': False,
            'position': (11, 4),
            'type': 'MOVABLE'
        },
        'CELL_75': {
            'fixed': False,
            'position': (11, 3),
            'type': 'MOVABLE'
        },
        'CELL_76': {
            'fixed': False,
            'position': (11, 2),
            'type': 'MOVABLE'
        },
        'CELL_77': {
            'fixed': False,
            'position': (7, 2),
            'type': 'MOVABLE'
        },
        'CELL_78': {
            'fixed': False,
            'position': (6, 0),
            'type': 'MOVABLE'
        },
        'CELL_79': {
            'fixed': False,
            'position': (5, 0),
            'type': 'MOVABLE'
        },
        'CELL_8': {
            'fixed': False,
            'position': (8, 6),
            'type': 'MOVABLE'
        },
        'CELL_80': {
            'fixed': False,
            'position': (3, 1),
            'type': 'MOVABLE'
        },
        'CELL_81': {
            'fixed': False,
            'position': (2, 0),
            'type': 'MOVABLE'
        },
        'CELL_82': {
            'fixed': False,
            'position': (1, 0),
            'type': 'MOVABLE'
        },
        'CELL_83': {
            'fixed': False,
            'position': (0, 0),
            'type': 'MOVABLE'
        },
        'CELL_84': {
            'fixed': False,
            'position': (0, 1),
            'type': 'MOVABLE'
        },
        'CELL_85': {
            'fixed': False,
            'position': (1, 1),
            'type': 'MOVABLE'
        },
        'CELL_86': {
            'fixed': False,
            'position': (2, 1),
            'type': 'MOVABLE'
        },
        'CELL_87': {
            'fixed': False,
            'position': (2, 2),
            'type': 'MOVABLE'
        },
        'CELL_88': {
            'fixed': False,
            'position': (1, 2),
            'type': 'MOVABLE'
        },
        'CELL_89': {
            'fixed': False,
            'position': (0, 2),
            'type': 'MOVABLE'
        },
        'CELL_9': {
            'fixed': False,
            'position': (7, 7),
            'type': 'MOVABLE'
        },
        'IO_0': {
            'fixed': True,
            'position': (3, 12),
            'type': 'IO'
        },
        'IO_1': {
            'fixed': True,
            'position': (0, 12),
            'type': 'IO'
        },
        'IO_2': {
            'fixed': True,
            'position': (8, 12),
            'type': 'IO'
        },
        'IO_3': {
            'fixed': True,
            'position': (7, 12),
            'type': 'IO'
        },
        'IO_4': {
            'fixed': True,
            'position': (7, 0),
            'type': 'IO'
        },
        'IO_5': {
            'fixed': True,
            'position': (4, 0),
            'type': 'IO'
        },
        'IO_6': {
            'fixed': True,
            'position': (3, 0),
            'type': 'IO'
        },
        'IO_7': {
            'fixed': True,
            'position': (0, 5),
            'type': 'IO'
        },
        'IO_8': {
            'fixed': True,
            'position': (2, 12),
            'type': 'IO'
        },
        'IO_9': {
            'fixed': True,
            'position': (12, 6),
            'type': 'IO'
        }
    },
    'grid_size': 13,
    'nets': [{
        'cells': ('CELL_0', 'CELL_1'),
        'name': 'NET_0'
    }, {
        'cells': ('CELL_1', 'CELL_2'),
        'name': 'NET_1'
    }, {
        'cells': ('CELL_2', 'CELL_3'),
        'name': 'NET_2'
    }, {
        'cells': ('CELL_3', 'CELL_4'),
        'name': 'NET_3'
    }, {
        'cells': ('CELL_4', 'CELL_5'),
        'name': 'NET_4'
    }, {
        'cells': ('CELL_5', 'CELL_6'),
        'name': 'NET_5'
    }, {
        'cells': ('CELL_6', 'CELL_7'),
        'name': 'NET_6'
    }, {
        'cells': ('CELL_7', 'CELL_8'),
        'name': 'NET_7'
    }, {
        'cells': ('CELL_8', 'CELL_9'),
        'name': 'NET_8'
    }, {
        'cells': ('CELL_9', 'CELL_10'),
        'name': 'NET_9'
    }, {
        'cells': ('CELL_10', 'CELL_11'),
        'name': 'NET_10'
    }, {
        'cells': ('CELL_11', 'CELL_12'),
        'name': 'NET_11'
    }, {
        'cells': ('CELL_12', 'CELL_13'),
        'name': 'NET_12'
    }, {
        'cells': ('CELL_13', 'CELL_14'),
        'name': 'NET_13'
    }, {
        'cells': ('CELL_14', 'CELL_15'),
        'name': 'NET_14'
    }, {
        'cells': ('CELL_15', 'CELL_16'),
        'name': 'NET_15'
    }, {
        'cells': ('CELL_16', 'CELL_17'),
        'name': 'NET_16'
    }, {
        'cells': ('CELL_17', 'CELL_18'),
        'name': 'NET_17'
    }, {
        'cells': ('CELL_18', 'CELL_19'),
        'name': 'NET_18'
    }, {
        'cells': ('CELL_19', 'CELL_20'),
        'name': 'NET_19'
    }, {
        'cells': ('CELL_20', 'CELL_21'),
        'name': 'NET_20'
    }, {
        'cells': ('CELL_21', 'CELL_22'),
        'name': 'NET_21'
    }, {
        'cells': ('CELL_22', 'CELL_23'),
        'name': 'NET_22'
    }, {
        'cells': ('CELL_23', 'CELL_24'),
        'name': 'NET_23'
    }, {
        'cells': ('CELL_24', 'CELL_25'),
        'name': 'NET_24'
    }, {
        'cells': ('CELL_25', 'CELL_26'),
        'name': 'NET_25'
    }, {
        'cells': ('CELL_26', 'CELL_27'),
        'name': 'NET_26'
    }, {
        'cells': ('CELL_27', 'CELL_28'),
        'name': 'NET_27'
    }, {
        'cells': ('CELL_28', 'CELL_29'),
        'name': 'NET_28'
    }, {
        'cells': ('CELL_29', 'CELL_30'),
        'name': 'NET_29'
    }, {
        'cells': ('CELL_30', 'CELL_31'),
        'name': 'NET_30'
    }, {
        'cells': ('CELL_31', 'CELL_32'),
        'name': 'NET_31'
    }, {
        'cells': ('CELL_32', 'CELL_33'),
        'name': 'NET_32'
    }, {
        'cells': ('CELL_33', 'CELL_34'),
        'name': 'NET_33'
    }, {
        'cells': ('CELL_34', 'CELL_35'),
        'name': 'NET_34'
    }, {
        'cells': ('CELL_35', 'CELL_36'),
        'name': 'NET_35'
    }, {
        'cells': ('CELL_36', 'CELL_37'),
        'name': 'NET_36'
    }, {
        'cells': ('CELL_37', 'CELL_38'),
        'name': 'NET_37'
    }, {
        'cells': ('CELL_38', 'CELL_39'),
        'name': 'NET_38'
    }, {
        'cells': ('CELL_39', 'CELL_40'),
        'name': 'NET_39'
    }, {
        'cells': ('CELL_40', 'CELL_41'),
        'name': 'NET_40'
    }, {
        'cells': ('CELL_41', 'CELL_42'),
        'name': 'NET_41'
    }, {
        'cells': ('CELL_42', 'CELL_43'),
        'name': 'NET_42'
    }, {
        'cells': ('CELL_43', 'CELL_44'),
        'name': 'NET_43'
    }, {
        'cells': ('CELL_44', 'CELL_45'),
        'name': 'NET_44'
    }, {
        'cells': ('CELL_45', 'CELL_46'),
        'name': 'NET_45'
    }, {
        'cells': ('CELL_46', 'CELL_47'),
        'name': 'NET_46'
    }, {
        'cells': ('CELL_47', 'CELL_48'),
        'name': 'NET_47'
    }, {
        'cells': ('CELL_48', 'CELL_49'),
        'name': 'NET_48'
    }, {
        'cells': ('CELL_49', 'CELL_50'),
        'name': 'NET_49'
    }, {
        'cells': ('CELL_50', 'CELL_51'),
        'name': 'NET_50'
    }, {
        'cells': ('CELL_51', 'CELL_52'),
        'name': 'NET_51'
    }, {
        'cells': ('CELL_52', 'CELL_53'),
        'name': 'NET_52'
    }, {
        'cells': ('CELL_53', 'CELL_54'),
        'name': 'NET_53'
    }, {
        'cells': ('CELL_54', 'CELL_55'),
        'name': 'NET_54'
    }, {
        'cells': ('CELL_55', 'CELL_56'),
        'name': 'NET_55'
    }, {
        'cells': ('CELL_56', 'CELL_57'),
        'name': 'NET_56'
    }, {
        'cells': ('CELL_57', 'CELL_58'),
        'name': 'NET_57'
    }, {
        'cells': ('CELL_58', 'CELL_59'),
        'name': 'NET_58'
    }, {
        'cells': ('CELL_59', 'CELL_60'),
        'name': 'NET_59'
    }, {
        'cells': ('CELL_60', 'CELL_61'),
        'name': 'NET_60'
    }, {
        'cells': ('CELL_61', 'CELL_62'),
        'name': 'NET_61'
    }, {
        'cells': ('CELL_62', 'CELL_63'),
        'name': 'NET_62'
    }, {
        'cells': ('CELL_63', 'CELL_64'),
        'name': 'NET_63'
    }, {
        'cells': ('CELL_64', 'CELL_65'),
        'name': 'NET_64'
    }, {
        'cells': ('CELL_65', 'CELL_66'),
        'name': 'NET_65'
    }, {
        'cells': ('CELL_66', 'CELL_67'),
        'name': 'NET_66'
    }, {
        'cells': ('CELL_67', 'CELL_68'),
        'name': 'NET_67'
    }, {
        'cells': ('CELL_68', 'CELL_69'),
        'name': 'NET_68'
    }, {
        'cells': ('CELL_69', 'CELL_70'),
        'name': 'NET_69'
    }, {
        'cells': ('CELL_70', 'CELL_71'),
        'name': 'NET_70'
    }, {
        'cells': ('CELL_71', 'CELL_72'),
        'name': 'NET_71'
    }, {
        'cells': ('CELL_72', 'CELL_73'),
        'name': 'NET_72'
    }, {
        'cells': ('CELL_73', 'CELL_74'),
        'name': 'NET_73'
    }, {
        'cells': ('CELL_74', 'CELL_75'),
        'name': 'NET_74'
    }, {
        'cells': ('CELL_75', 'CELL_76'),
        'name': 'NET_75'
    }, {
        'cells': ('CELL_76', 'CELL_77'),
        'name': 'NET_76'
    }, {
        'cells': ('CELL_77', 'CELL_78'),
        'name': 'NET_77'
    }, {
        'cells': ('CELL_78', 'CELL_79'),
        'name': 'NET_78'
    }, {
        'cells': ('CELL_79', 'CELL_80'),
        'name': 'NET_79'
    }, {
        'cells': ('CELL_80', 'CELL_81'),
        'name': 'NET_80'
    }, {
        'cells': ('CELL_81', 'CELL_82'),
        'name': 'NET_81'
    }, {
        'cells': ('CELL_82', 'CELL_83'),
        'name': 'NET_82'
    }, {
        'cells': ('CELL_83', 'CELL_84'),
        'name': 'NET_83'
    }, {
        'cells': ('CELL_84', 'CELL_85'),
        'name': 'NET_84'
    }, {
        'cells': ('CELL_85', 'CELL_86'),
        'name': 'NET_85'
    }, {
        'cells': ('CELL_86', 'CELL_87'),
        'name': 'NET_86'
    }, {
        'cells': ('CELL_87', 'CELL_88'),
        'name': 'NET_87'
    }, {
        'cells': ('CELL_88', 'CELL_89'),
        'name': 'NET_88'
    }, {
        'cells': ('IO_0', 'CELL_68'),
        'name': 'NET_89'
    }, {
        'cells': ('IO_1', 'CELL_15'),
        'name': 'NET_90'
    }, {
        'cells': ('IO_2', 'CELL_48'),
        'name': 'NET_91'
    }, {
        'cells': ('IO_3', 'CELL_10'),
        'name': 'NET_92'
    }, {
        'cells': ('IO_4', 'CELL_70'),
        'name': 'NET_93'
    }, {
        'cells': ('IO_5', 'CELL_37'),
        'name': 'NET_94'
    }, {
        'cells': ('IO_6', 'CELL_80'),
        'name': 'NET_95'
    }, {
        'cells': ('IO_7', 'CELL_79'),
        'name': 'NET_96'
    }, {
        'cells': ('IO_8', 'CELL_46'),
        'name': 'NET_97'
    }, {
        'cells': ('IO_9', 'CELL_73'),
        'name': 'NET_98'
    }]
}